#ifndef _IPL_MODE_AR0330_TVP5150_CARDV_FFFF_INT_H_
#define _IPL_MODE_AR0330_TVP5150_CARDV_FFFF_INT_H_
/**
    IPL_Mode_AR0330_TVP5150_CARDV_FFFF_Int.h


    @file       IPL_Mode_AR0330_TVP5150_CARDV_FFFF_Int.h
    @ingroup    mISYSAlg
    @note       Nothing (or anything need to be mentioned).

    Copyright   Novatek Microelectronics Corp. 2011.  All rights reserved.
*/

IPL_CMD_CHGMODE_FP IPL_GetModeFp(IPL_MODE CurMode, IPL_MODE NextMode);

#endif //_IPL_MODE_OV2710_INT_H_